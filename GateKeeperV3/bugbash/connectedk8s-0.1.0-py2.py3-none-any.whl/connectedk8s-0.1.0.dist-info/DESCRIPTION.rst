Microsoft Azure CLI 'connectedk8s' Extension


