# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

from knack.util import CLIError

from azext_k8sconfiguration.vendored_sdks.models.source_control_configuration_py3 import SourceControlConfiguration
from azext_k8sconfiguration.vendored_sdks.models.helm_operator_properties import HelmOperatorProperties

def show_k8sconfiguration(cmd, client, resource_group_name, cluster_name, name, configuration_type='sourceControlConfiguration', cluster_type='connectedClusters', api_version='2019-11-01-preview'):
    if 'connectedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.Kubernetes'
    elif  'managedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.ContainerService'
    else:
        raise CLIError("Invalid cluster-type.  Supported values are 'connectedClusters' and 'managedClusters'.")

    if configuration_type.lower() != 'sourcecontrolconfiguration':
        raise CLIError('Invalid configuration_type.  Valid value is "sourceControlConfiguration"')
    else:
        source_control_configuration_name = name

    if api_version is None:
        api_version = client.api_version

    return client.get(resource_group_name, cluster_rp, cluster_type, cluster_name, source_control_configuration_name, api_version)

def create_k8sconfiguration(cmd, client, resource_group_name, cluster_name, name, repository_url, operator_instance_name=None, operator_namespace='default', configuration_type='sourceControlConfiguration',
                                   cluster_type='connectedClusters', operator_params=None, operator_scope='cluster', operator_type='flux', enable_helm_operator='false',
                                   helm_operator_chart_version='0.2.0', helm_operator_chart_values='', api_version='2019-11-01-preview'):
    if 'connectedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.Kubernetes'
    elif  'managedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.ContainerService'
    else:
        raise CLIError("Invalid cluster-type.  Supported values are 'connectedClusters' and 'managedClusters'.")

    if configuration_type.lower() != 'sourcecontrolconfiguration':
        raise CLIError('Invalid configuration_type.  Valid value is "sourceControlConfiguration"')
    else:
        source_control_configuration_name = name

    if operator_instance_name is None:
        operator_instance_name = source_control_configuration_name

    helm_operator_properties = HelmOperatorProperties()

    if enable_helm_operator == 'true':
        helm_operator_properties.chart_version = helm_operator_chart_version
        helm_operator_properties.chart_values = helm_operator_chart_values
    else:
        helm_operator_properties = None

    source_control_configuration = SourceControlConfiguration(repository_url=repository_url,
                                                              operator_namespace=operator_namespace,
                                                              operator_instance_name=operator_instance_name,
                                                              operator_type=operator_type,
                                                              operator_params=operator_params,
                                                              operator_scope=operator_scope,
                                                              enable_helm_operator=enable_helm_operator,
                                                              helm_operator_properties=helm_operator_properties)

    return client.create_or_update(resource_group_name, cluster_rp, cluster_type, cluster_name, source_control_configuration_name, api_version, source_control_configuration)


def list_k8sconfiguration(cmd, client, resource_group_name, cluster_name, cluster_type='connectedClusters', api_version='2019-11-01-preview'):
    if 'connectedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.Kubernetes'
    elif  'managedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.ContainerService'
    else:
        raise CLIError("Invalid cluster-type.  Supported values are 'connectedClusters' and 'managedClusters'.")

    return client.list(resource_group_name, cluster_rp, cluster_type, cluster_name, api_version)

def delete_k8sconfiguration(cmd, client, resource_group_name, cluster_name, name, configuration_type='sourceControlConfiguration', cluster_type='connectedClusters', api_version='2019-11-01-preview'):
    if 'connectedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.Kubernetes'
    elif  'managedclusters' == cluster_type.lower():
        cluster_rp = 'Microsoft.ContainerService'
    else:
        raise CLIError("Invalid cluster-type.  Supported values are 'connectedClusters' and 'managedClusters'.")

    if configuration_type.lower() != 'sourcecontrolconfiguration':
        raise CLIError('Invalid configuration_type.  Valid value is "sourceControlConfiguration"')
    else:
        source_control_configuration_name = name

    custom_headers = {"x-ms-force": "true"}

    return client.delete(resource_group_name, cluster_rp, cluster_type, cluster_name, source_control_configuration_name, api_version, custom_headers)


#
# def update_k8sconfiguration(cmd, instance, tags=None):
#     with cmd.update_context(instance) as c:
#         c.set_param('tags', tags)
#     return instance