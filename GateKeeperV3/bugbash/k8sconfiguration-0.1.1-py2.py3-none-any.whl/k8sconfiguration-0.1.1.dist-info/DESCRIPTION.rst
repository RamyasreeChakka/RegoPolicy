Microsoft Azure CLI 'k8sconfiguration' Extension


